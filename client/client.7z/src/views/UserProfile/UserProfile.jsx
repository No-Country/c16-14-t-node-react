import styles from './UserProfile.module.css'

const UserProfile = () => {
  return (
    <div>
      Perfil de usuario
    </div>
  )
}

export default UserProfile
