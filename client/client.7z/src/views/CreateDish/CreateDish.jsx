import React, { useState } from 'react';
import styles from './CreateDish.module.css'
import { Link } from 'react-router-dom';

const DishForm = () => {
  const [formData, setFormData] = useState({
    name: '',
    ingredients: [''], // Initial ingredient
    steps: [''], // Initial step
  });

  const handleChange = (e, field, index) => {
    const value = e.target.value;
    if (field === 'ingredients') {
      const updatedIngredients = [...formData.ingredients];
      updatedIngredients[index] = value;
      setFormData({ ...formData, ingredients: updatedIngredients });
    } else if (field === 'steps') {
      const updatedSteps = [...formData.steps];
      updatedSteps[index] = value;
      setFormData({ ...formData, steps: updatedSteps });
    } else {
      setFormData({ ...formData, [field]: value });
    }
  };

  const addField = (field) => {
    if (field === 'ingredients') {
      setFormData({ ...formData, ingredients: [...formData.ingredients, ''] });
    } else if (field === 'steps') {
      setFormData({ ...formData, steps: [...formData.steps, ''] });
    }
  };

  const removeField = (field, index) => {
    if (field === 'ingredients') {
      const updatedIngredients = formData.ingredients.filter((_, i) => i !== index);
      setFormData({ ...formData, ingredients: updatedIngredients });
    } else if (field === 'steps') {
      const updatedSteps = formData.steps.filter((_, i) => i !== index);
      setFormData({ ...formData, steps: updatedSteps });
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(formData); 
  };

  return (
    <div className={`${styles.container} mx-auto`}>
      <img src="icon-nav.svg" alt="logo redsabor" />
      <div className="flex mt-8">
        <div>
          <p className={styles.title}>Únete <br /> a la mejor comunidad culinaria</p>
          <img src="cooking-img.svg" alt="imagen mujer cocinando" />
        </div>

        <div className={`${styles.formContainer} flex flex-col`}>
          <p className="text-3xl font-bold">Iniciar sesión</p>
          <span>¿No tienes una cuenta? <Link to='/sign-up'><strong>Regístrate aquí</strong></Link></span>
          <form onSubmit={handleSubmit} className={`${styles.formContainer} flex flex-col`}>
      <div>
        <label htmlFor="name">Name:</label>
        <input type="text" id="name" name="name" value={formData.name} onChange={(e) => handleChange(e, 'name')} />
      </div>
      <div>
        <label>Ingredients:</label>
        {formData.ingredients.map((ingredient, index) => (
          <div key={index}>
            <input
              type="text"
              value={ingredient}
              onChange={(e) => handleChange(e, 'ingredients', index)}
            />
            <button type="button" onClick={() => removeField('ingredients', index)}>Remove Ingredient</button>
          </div>
        ))}
        <button type="button" onClick={() => addField('ingredients')}>Add Ingredient</button>
      </div>
      <div>
        <label>Steps:</label>
        {formData.steps.map((step, index) => (
          <div key={index}>
            <p>Step {index + 1}:</p> {/* Display the number of the step */}
            <input
              type="text"
              value={step}
              onChange={(e) => handleChange(e, 'steps', index)}
            />
            <button type="button" onClick={() => removeField('steps', index)}>Remove Step</button>
          </div>
        ))}
        <button type="button" onClick={() => addField('steps')}>Add Step</button>
      </div>
      <button type="submit">Submit</button>
    </form>
          
        </div>
      </div>
    </div>
    
  );
};

export default DishForm;
