import { Link } from "react-router-dom";
import styles from './Login.module.css';
import { useState } from "react";
import axios from "axios";
import { useAuth } from "../../utils/AuthProvider";

const Login = () => {

  const [user, setUser] = useState('');
  const auth = useAuth();

  const [form, setForm] = useState({
    email: '',
    username: '',
    nationality: '',
    password: ''
  });

  const [errors, setErrors] = useState({
    email: '',
    username: '',
    nationality: '',
    password: ''
  })

  const changeHandler = (e) => {
    const property = e.target.name;
    let value = e.target.value;

    validate({...form, [property]: value})

    setForm({...form, [property]: value})
  }

  const validate = (form) => {
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    const passwordRegex = /^(?=.*[0-9])(?=.*[A-Z]).{6,16}$/;

    const newErrors = {
      email: '',
      username: '',
      nationality: '',
      password: ''
    };

    let passed = true
    
    if(!emailRegex.test(form.email)) {
      newErrors.email = 'Ingrese un email válido';
      passed = false
    }
    
    if(!form.nationality) {
      newErrors.nationality = 'Elige tu país de origen';
      passed = false
    }
    
    if(!passwordRegex.test(form.password)) {
      newErrors.password = 'La contraseña debe tener entre 6 y 16 caracteres con al menos una mayúscula y un número';
      passed = false
    }

    setErrors(newErrors);

    return passed;
  }

  const submitHandler = (e) => {
    e.preventDefault();

    const isValid = validate(form);

    if(isValid) {
      axios.post('http://localhost:3001/user/sign-up', form)
        .then(() => {
          setForm({
            email: '',
            username: '',
            nationality: '',
            password: '',
          });
        })
        .catch((err) => {
          console.log(err);
        });
    }
  }

  return (
    <div className={`${styles.container} mx-auto`}>
      <img src="icon-nav.svg" alt="logo redsabor" />
      <div className="flex mt-8">
        <div>
          <p className={styles.title}>Únete <br /> a la mejor comunidad culinaria</p>
          <img src="cooking-img.svg" alt="imagen mujer cocinando" />
        </div>

        <div className={`${styles.formContainer} flex flex-col`}>
          <p className="text-3xl font-bold">Iniciar sesión</p>
          <span>¿No tienes una cuenta? <Link to='/sign-up'><strong>Regístrate aquí</strong></Link></span>
          <form onSubmit={submitHandler} className={`${styles.formContainer} flex flex-col`}>
            <input type="text" placeholder="Ingresa tu email" name="email" value={form.email} onChange={changeHandler} />
            <input type="password" placeholder="Ingresa tu contraseña" name="password" value={form.password} onChange={changeHandler} />
            <button type="submit">Ingresar</button>
          </form>
          
        </div>
      </div>
    </div>
  )
}

export default Login
