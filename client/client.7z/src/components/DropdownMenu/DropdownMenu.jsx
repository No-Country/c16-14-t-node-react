import styles from './DropdownMenu.module.css'

const DropdownMenu = () => {

  return (
    <div className={`flex flex-col top-10 ${styles.dropdown}`}>
      <ul className="flex flex-col gap-2">
          <li>Crear nueva receta</li>
          <li>Mis recetas</li>
          <li>Recetas guardadas</li>
          <li>Mi perfil</li>
          <li>Cerrar sesión</li>
        </ul>
    </div>
  );
}

export default DropdownMenu
