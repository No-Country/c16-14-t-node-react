import { AuthProvider } from './utils/AuthProvider';
import { Route, Routes, useLocation } from 'react-router-dom';
import { CreateDish, Home, Login, Register, UserProfile } from './views';
import NavBar from './components/NavBar/NavBar';

function App() {

  const locaction = useLocation().pathname;

  return (
    <AuthProvider>
      {locaction === '/' && <NavBar />}
      <Routes>
      <Route path='/' element={<Home />} />
      <Route path='/login' element={<Login />} />
      <Route path='/sign-up' element={<Register />} />
      <Route path='/newdish' element={<CreateDish />} />
      <Route path='/profile' element={<UserProfile />} />
      </Routes>
    </AuthProvider>
  )
}

export default App
